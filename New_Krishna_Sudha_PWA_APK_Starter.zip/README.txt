NEW KRISHNA SUDHA ENTERPRISE - PWA PACKAGE

Files:
- index.html: calculator website
- manifest.json: installable PWA metadata
- sw.js: basic offline cache
- icons/: app icons

DEPLOY:
1. Upload all files and the icons folder to the ROOT of a GitHub repository.
2. Ensure index.html is at repository root.
3. GitHub repository -> Settings -> Pages -> Deploy from a branch -> main -> /(root) -> Save.
4. Wait for GitHub Pages to publish. The URL must use HTTPS.
5. Open the published HTTPS URL in Chrome and test the calculator.
6. For Android packaging, open https://www.pwabuilder.com, enter the published URL, validate the PWA, then choose Package for stores -> Android.

IMPORTANT:
- This package does NOT provide automatic official company price syncing. It is still a manual rate entry calculator with official source links.
- For live syncing, a backend and authorized company API/feed or reliable official price data source are required.
- Do not publish private dealer credentials or sensitive information in a public repository.
